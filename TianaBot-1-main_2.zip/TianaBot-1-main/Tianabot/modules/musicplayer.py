__mod_name__ = "VC MUSIC"
__help__ = """
 ❍ /search <query> : Search videos on youtube with details.
 ❍ /song <song name> : Download songs you want quickly.
 ❍ /deezer <song name> : Download songs you want quickly via deezer.
 ❍ /saavn <song name> : Download songs you want quickly via saavn.
 ❍ /video <video name> : Download videos you want quickly.
 ❍ /vsong <song name> : Download video songs.
 ❍ /vchelp : Do this to open VC help module."""

