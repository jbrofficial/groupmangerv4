## TIANA BOT
THIS IS GROUP MANAGER BOT.
# DEPLOYMENT
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[![Python](http://forthebadge.com/images/badges/made-with-python.svg)](https://python.org)&nbsp;
[![ForTheBadge built-with-love](http://ForTheBadge.com/images/badges/built-with-love.svg)](https://GitHub.com/TEAMOFDEVIL-X/)


&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;![LICENSE](https://img.shields.io/github/license/TEAMOFDEVIL-X/TIANABOT?style=for-the-badge&logo=appveyor)&nbsp;
![Contributors](https://img.shields.io/github/contributors/TEAMOFDEVIL-X/TIANABOT?style=for-the-badge&logo=appveyor)&nbsp;
![Repository Size](https://img.shields.io/github/repo-size/TEAMOFDEVIL-X/TIANABOT?style=for-the-badge&logo=appveyor)


&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;![Python Version](https://img.shields.io/badge/python-3.8-green?style=for-the-badge&logo=appveyor)&nbsp;
![Issues](https://img.shields.io/github/issues/TEAMOFDEVIL-X/TIANABOT?style=for-the-badge&logo=appveyor)&nbsp;
![Forks](https://img.shields.io/github/forks/TEAMOFDEVIL-X/TIANABOT?style=for-the-badge&logo=appveyor)&nbsp;
![Stars](https://img.shields.io/github/stars/TEAMOFDEVIL-X/TIANABOT?style=for-the-badge&logo=appveyor)


![Deploy](https://telegra.ph/file/bcd7b3dec21d1c2b2583a.png)

## DEPLOY HERE 

The easiest way to deploy this Bot

<p align="center"><a href="https://heroku.com/deploy?template=https://github.com/TEAMOFDEVIL-X/TIANA"> <img src="https://img.shields.io/badge/Deploy%20To%20Heroku-black?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>

BOT MAKER - [PRINCE](https://t.me/Prince_3011)

### TELEGRAM
Check me on [TELEGRAM](https://t.me/tiana_prince_bot)

